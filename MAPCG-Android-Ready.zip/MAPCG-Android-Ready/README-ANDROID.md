# MAPCG Android build

This drop-in project wraps the existing MAPCG web application in Android WebView.

## Install into MAPCG

Copy the `.github` folder and `android` folder from this package into the root of your MAPCG repository, replacing files with the same names.

The GitHub Actions workflow automatically copies the complete MAPCG repository into `android/app/src/main/assets/www/` at build time. The source HTML, textures, icons, subjects, music, API, and multiplayer directories are therefore kept in their existing locations.

## GitHub Actions

Open **Actions → Build MAPCG APK → Run workflow**. After a successful run, open the workflow run and download the artifact named **MAPCG-APK**.

The resulting file is `app-release.apk` and is an unsigned release APK suitable for direct installation/testing. A Play Store upload would require a signing configuration.

## Technical choices

- Android Gradle Plugin 8.13.2
- Gradle 8.13
- JDK 17
- compileSdk/targetSdk 36
- minSdk 24
- AndroidX WebKit 1.17.0
- `WebViewAssetLoader` for local MAPCG files
- Internet permission for MAPCG's network features
- Landscape orientation
- Immersive fullscreen
