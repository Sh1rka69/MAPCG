# MAPCG uses a WebView and does not currently require custom R8 rules.
